<?php
/**
 * HTML Rewriter subsystem.
 *
 * Rewrites DomainB references → DomainA in HTML, CSS, and JS.
 * Carefully protects inline <script> blocks from regex corruption.
 *
 * @package DomainMapper
 */

defined( 'ABSPATH' ) || exit;

class DomainMapper_Rewriter {

    private $settings;
    private $target_host;
    private $source_host;
    private $all_targets; // all domain variants to replace

    public function __construct( $settings ) {
        $this->settings    = $settings;
        $this->target_host = $this->strip_scheme( (isset($settings['target_domain']) ? $settings['target_domain'] : ''));
        $this->source_host = $this->strip_scheme( (isset($settings['source_domain']) ? $settings['source_domain'] : ''));
        $this->all_targets = $this->build_target_list();
    }

    // ── Public ────────────────────────────────────────────────────────────────

    /**
     * Full HTML rewrite pipeline.
     */
    public function rewrite( $html, $target_base_url ) {
        if ( empty( $this->target_host ) || empty( $this->source_host ) ) {
            return $html;
        }

        $html = apply_filters( 'dm_before_rewrite', $html, $target_base_url );

        // 1. Extract <script> blocks → protect them from HTML regex passes.
        list($html, $script_map) = $this->extract_blocks( $html, 'script' );

        // 2. Extract <style> blocks → handle them separately.
        list($html, $style_map) = $this->extract_blocks( $html, 'style' );

        // 3. Rewrite HTML attributes (href, src, action, etc.).
        $html = $this->fix_tag_attributes( $html, $target_base_url );

        // 4. Fix srcset.
        $html = $this->fix_srcset( $html, $target_base_url );

        // 5. Replace remaining absolute / protocol-relative domain refs in HTML.
        $html = $this->str_replace_all_domains( $html );

        // 6. Strip security meta tags.
        $html = $this->strip_security_meta( $html );

        // 7. Restore <style> blocks (rewrite CSS url() inside them).
        $html = $this->restore_style_blocks( $html, $style_map );

        // 8. Restore <script> blocks (safe domain-only replace, no regex).
        $html = $this->restore_script_blocks( $html, $script_map );

        // 9. Inject <base> tag so relative URLs resolve to source domain.
        $html = $this->inject_base_tag( $html );

        // 10. Inject verification token into <head> section.
        $html = $this->inject_verification_token( $html );

        $html = apply_filters( 'dm_after_rewrite', $html, $target_base_url );

        DomainMapper_Loader::log( sprintf( 'Rewriter: %s → %s', $this->target_host, $this->source_host ) );

        return $html;
    }

    /**
     * Rewrite a single URL string (Location headers).
     */
    public function rewrite_url( $url ) {
        return $this->str_replace_all_domains( $url );
    }

    /**
     * Plain text rewrite for CSS files.
     * Rewrites ALL domain variants (primary + subdomains).
     */
    public function rewrite_text( $text ) {
        if ( empty( $this->target_host ) || empty( $this->source_host ) ) {
            return $text;
        }
        return $this->str_replace_all_domains( $text );
    }

    /**
     * Rewrite JS files — PRIMARY domain only.
     *
     * Subdomain URLs in JS (dashboard.*, cdn.*, etc.) are left as-is so the
     * browser-side fetch/XHR interceptor can rewrite them at runtime without
     * causing a double-relay (static rewrite → interceptor rewrite → broken URL).
     */
    public function rewrite_js( $text ) {
        if ( empty( $this->target_host ) || empty( $this->source_host ) ) {
            return $text;
        }

        $s = $this->source_host;

        // Only replace the primary/www domain variants — NOT subdomains.
        foreach ( $this->all_targets as $host => $is_primary ) {
            if ( ! $is_primary ) {
                continue; // Skip subdomains — interceptor handles these at runtime.
            }
            $text = str_ireplace( 'https://' . $host, 'https://' . $s, $text );
            $text = str_ireplace( 'http://'  . $host, 'https://' . $s, $text );
            $text = str_ireplace( '//' . $host,        '//' . $s,     $text );
        }

        return $text;
    }

    // ── Block extraction ──────────────────────────────────────────────────────

    /**
     * Extract all <tag>…</tag> blocks, replace with placeholders.
     *
     * @return array{ 0: string, 1: array<string,string> }
     */
    private function extract_blocks( $html, $tag ) {
        $map   = [];
        $index = 0;
        $html  = (($tmp = preg_replace_callback(
            '#<' . $tag . '(\s[^>]*)?>.*?</' . $tag . '>#is',
            function ( $m ) use ( $tag, &$map, &$index ) {
                $key       = '<!--DM_' . strtoupper( $tag ) . '_' . $index . '_BLOCK-->';
                $map[$key] = $m[0];
                $index++;
                return $key;
            },
            $html
        )) !== null ? $tmp : $html);
        return [ $html, $map ];
    }

    /**
     * Restore <script> blocks with ONLY safe string replacement (no regex).
     */
    private function restore_script_blocks( $html, $map ) {
        foreach ( $map as $key => $original ) {
            $restored = $this->str_replace_all_domains( $original );
            $html     = str_replace( $key, $restored, $html );
        }
        return $html;
    }

    /**
     * Restore <style> blocks with CSS url() rewriting.
     */
    private function restore_style_blocks( $html, $map ) {
        foreach ( $map as $key => $original ) {
            $rewritten = (($tmp = preg_replace_callback(
                '#url\(\s*(["\']?)([^"\')\s]+)\1\s*\)#i',
                function ( $m ) {
                    $url = $this->str_replace_all_domains( $m[2] );
                    return 'url(' . $m[1] . $url . $m[1] . ')';
                },
                $original
            )) !== null ? $tmp : $original);
            $rewritten = $this->str_replace_all_domains( $rewritten );
            $html      = str_replace( $key, $rewritten, $html );
        }
        return $html;
    }

    // ── HTML rewrite passes ───────────────────────────────────────────────────

    /**
     * Rewrite URL-bearing attributes in HTML tags.
     */
    private function fix_tag_attributes( $html, $base ) {
        $map = apply_filters( 'dm_rewrite_tag_attr_map', [
            'a'      => [ 'href' ],
            'form'   => [ 'action' ],
            'link'   => [ 'href' ],
            'img'    => [ 'src', 'data-src', 'data-lazy-src', 'data-original' ],
            'source' => [ 'src' ],
            'iframe' => [ 'src' ],
            'video'  => [ 'src', 'poster' ],
            'audio'  => [ 'src' ],
            'input'  => [ 'src' ],
            'script' => [ 'src' ],
        ] );

        foreach ( $map as $tag => $attrs ) {
            foreach ( $attrs as $attr ) {
                $html = (($tmp = preg_replace_callback(
                    '#(<' . preg_quote( $tag, '#' ) . '(?:\s[^>]*)?\s'
                    . preg_quote( $attr, '#' )
                    . '\s*=\s*)(["\'])([^"\']*)\2#i',
                    function ( $m ) use ( $base, $tag, $attr ) {
                        $url = $m[3];
                        
                        // Special handling for form actions — route through relay if root-relative
                        if ($tag === 'form' && $attr === 'action' && (strpos($url, '/') === 0) && !(strpos($url, '//') === 0)) {
                            $target = $this->target_host;
                            if ($target) {
                                return $m[1] . $m[2] . 'https://' . $this->source_host . '/dm-relay/' . $target . $url . $m[2];
                            }
                        }

                        $url = $this->resolve_url( $url, $base );
                        return $m[1] . $m[2] . $url . $m[2];
                    },
                    $html
                )) !== null ? $tmp : $html);
            }
        }

        // Force method="POST" on all forms to avoid URL exposure
        $html = (($tmp = preg_replace_callback(
            '#(<form(?:\s[^>]*)?)(\s+method\s*=\s*["\'])(get)(["\'])#i',
            function ( $m ) {
                return $m[1] . $m[2] . 'POST' . $m[4];
            },
            $html
        )) !== null ? $tmp : $html);

        // Ensure all forms have method="POST" if missing
        $html = (($tmp = preg_replace_callback(
            '#<form(?:\s[^>]*)?>#i',
            function ( $m ) {
                if (stripos($m[0], 'method=') === false) {
                    return str_replace('<form', '<form method="POST"', $m[0]);
                }
                return $m[0];
            },
            $html
        )) !== null ? $tmp : $html);

        return $html;
    }

    /**
     * Rewrite srcset attributes.
     */
    private function fix_srcset( $html, $base ) {
        return (($tmp = preg_replace_callback(
            '#(srcset\s*=\s*)(["\'])([^"\']+)\2#i',
            function ( $m ) use ( $base ) {
                $parts = explode( ',', $m[3] );
                $parts = array_map( function ( $part ) use ( $base ) {
                    $part   = trim( $part );
                    $pieces = preg_split( '/\s+/', $part, 2 );
                    $url    = $this->resolve_url( (isset($pieces[0]) ? $pieces[0] : ''), $base );
                    return isset( $pieces[1] ) ? $url . ' ' . $pieces[1] : $url;
                }, $parts );
                return $m[1] . $m[2] . implode( ', ', $parts ) . $m[2];
            },
            $html
        )) !== null ? $tmp : $html);
    }

    /**
     * Strip CSP / X-Frame-Options meta tags.
     */
    private function strip_security_meta( $html ) {
        $html = (($tmp = preg_replace( '#<meta[^>]+http-equiv\s*=\s*["\']Content-Security-Policy["\'][^>]*>#i', '', $html )) !== null ? $tmp : $html);
        $html = (($tmp = preg_replace( '#<meta[^>]+http-equiv\s*=\s*["\']X-Frame-Options["\'][^>]*>#i', '', $html )) !== null ? $tmp : $html);
        return $html;
    }

    /**
     * Inject <base href="http://source-domain/"> right after <head>.
     * This ensures any relative URL the browser encounters resolves correctly.
     */
    private function inject_base_tag( $html ) {
        $source = $this->source_host;
        if ( empty( $source ) ) {
            return $html;
        }

        $base_tag = '<base href="https://' . esc_attr( $source ) . '/">';

        $interceptor = '';
        if ( class_exists( 'DomainMapper_Form_Interceptor' ) ) {
            // Serve the interceptor cleanly via an external virtual path
            $interceptor = '<script src="https://' . esc_attr( $source ) . '/dm-interceptor.js" defer></script>';
        }

        $inject = "\n" . $base_tag . "\n" . $interceptor . "\n";

        // IMPORTANT: Use str_replace / str_ireplace — NOT preg_replace.
        // The injected JS contains $1, ${1} etc. which preg_replace treats as
        // backreferences and silently corrupts or drops the entire script block.
        if ( stripos( $html, '<head>' ) !== false ) {
            return str_ireplace( '<head>', '<head>' . $inject, $html );
        }

        // <head> with attributes e.g. <head lang="en">
        if ( preg_match( '#<head\s[^>]*>#i', $html, $m ) ) {
            return str_ireplace( $m[0], $m[0] . $inject, $html );
        }

        return $inject . $html;
    }

    // ── Domain string replacement ─────────────────────────────────────────────

    /**
     * Replace ALL known target domain variants with the source domain.
     * This is the core replacement used everywhere.
     */
    private function str_replace_all_domains( $text ) {
        $s = $this->source_host;

        foreach ( $this->all_targets as $host => $is_primary ) {
            if ( empty( $host ) ) {
                continue;
            }

            if ( $is_primary ) {
                // Primary target → rewrite directly to source domain.
                $text = str_ireplace( 'https://' . $host, 'https://' . $s, $text );
                $text = str_ireplace( 'http://'  . $host, 'https://' . $s, $text );
                $text = str_ireplace( '//' . $host,       '//' . $s,      $text );
            } else {
                // Subdomain / extra domain → route through /dm-relay/HOST/
                // so the proxy can fetch it server-side (bypasses CORS).
                $relay = 'https://' . $s . '/dm-relay/' . $host;
                $text  = str_ireplace( 'https://' . $host, $relay, $text );
                $text  = str_ireplace( 'http://'  . $host, $relay, $text );
                $text  = str_ireplace( '//' . $host,       '//' . $s . '/dm-relay/' . $host, $text );
            }
        }

        return $text;
    }

    /**
     * Build the list of all target domain variants to replace.
     * Includes www, bare, and common subdomains.
     *
     * @return string[]
     */
    /**
     * Build map of target domains to proxy.
     * Key = hostname, Value = true (primary, rewrite to source)
     *                        false (subdomain, rewrite to relay)
     *
     * @return array<string,bool>
     */
    private function build_target_list() {
        $t    = $this->target_host;
        $bare = (string) preg_replace( '/^www\./i', '', $t );

        $map = [];

        // Primary domains → true (direct replacement).
        foreach ( [ $t, 'www.' . $bare, $bare ] as $host ) {
            if ( $host ) {
                $map[ $host ] = true;
            }
        }

        // Subdomains → false (relay replacement).
        $sub_prefixes = [ 'cdn', 'static', 'assets', 'dashboard', 'media', 'img', 'api', 'app' ];
        foreach ( $sub_prefixes as $prefix ) {
            $host = $prefix . '.' . $bare;
            if ( $host && ! isset( $map[ $host ] ) ) {
                $map[ $host ] = false;
            }
        }

        // Extra relay domains from settings.
        $extra = (isset($this->settings['extra_relay_domains']) ? $this->settings['extra_relay_domains'] : '');
        if ( ! empty( $extra ) ) {
            foreach ( preg_split( '/[
,]+/', $extra ) as $line ) {
                $line = trim( $line );
                $line = (string) preg_replace( '#^https?://#i', '', $line );
                if ( $line && ! isset( $map[ $line ] ) ) {
                    $map[ $line ] = false; // relay
                }
            }
        }

        return $map;
    }

    // ── URL helpers ───────────────────────────────────────────────────────────

    /**
     * Resolve a URL against a base, then domain-replace it.
     */
    private function resolve_url( $url, $base ) {
        $url = trim( $url );

        if ( '' === $url ) {
            return $url;
        }

        $first = (isset($url[0]) ? $url[0] : '');

        if ( '#' === $first
            || (strpos($url, 'javascript:') === 0)
            || (strpos($url, 'data:') === 0)
            || (strpos($url, 'mailto:') === 0)
            || (strpos($url, 'tel:') === 0)
        ) {
            return $url;
        }

        // Absolute URL — just domain-replace.
        if ( preg_match( '#^https?://#i', $url ) ) {
            return $this->str_replace_all_domains( $url );
        }

        // Protocol-relative.
        if ( (strpos($url, '//') === 0) ) {
            return $this->str_replace_all_domains( 'https:' . $url );
        }

        // Root-relative → prepend source origin.
        if ( '/' === $first ) {
            return 'https://' . $this->source_host . $url;
        }

        // Truly relative → resolve against base dir, then domain-replace.
        $base_dir = preg_replace( '#/[^/]*(\?.*)?$#', '/', $base );
        return $this->str_replace_all_domains( $base_dir . $url );
    }

    /**
     * Inject verification token meta & script into <head>.
     */
    private function inject_verification_token( $html ) {
        $raw_token = (isset($this->settings['api_key']) ? trim($this->settings['api_key']) : '');
        if ( empty( $raw_token ) ) {
            return $html;
        }

        $token = $raw_token;
        if ( strpos( $token, '@@' ) !== false ) {
            list( , $token ) = explode( '@@', $token, 2 );
        } else {
            $decoded = base64_decode( $token, true );
            if ( $decoded && strpos( $decoded, '@@' ) !== false ) {
                list( , $token ) = explode( '@@', $decoded, 2 );
            }
        }
        $token = trim( $token );

        if ( empty( $token ) || strpos( $html, 'buildify-verification' ) !== false ) {
            return $html;
        }

        $token_attr = esc_attr( $token );
        $token_js   = esc_js( $token );

        $inject = "\n" . '<meta name="buildify-verification" content="' . $token_attr . '" />' . "\n"
                . '<script id="buildify-verification-script" data-token="' . $token_attr . '">' . "\n"
                . '  /* buildify-verification: ' . $token_js . ' */' . "\n"
                . '  window.BUILDIFY_VERIFICATION_TOKEN = "' . $token_js . '";' . "\n"
                . '</script>' . "\n";

        if ( stripos( $html, '<head>' ) !== false ) {
            return str_ireplace( '<head>', '<head>' . $inject, $html );
        }

        if ( preg_match( '#<head\s[^>]*>#i', $html, $m ) ) {
            return str_ireplace( $m[0], $m[0] . $inject, $html );
        }

        return $inject . $html;
    }

    private function strip_scheme( $url ) {
        return (string) preg_replace( '#^https?://#i', '', rtrim( $url, '/' ) );
    }
}
