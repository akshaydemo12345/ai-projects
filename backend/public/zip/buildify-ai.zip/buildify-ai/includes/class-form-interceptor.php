<?php
/**
 * Form Interceptor.
 *
 * Provides two APIs:
 *   get_script()   — emits a single clean external <script src="..."> tag into the HTML.
 *   get_js_body()  — returns the raw JS body served by class-proxy.php at /dm-interceptor.js.
 *
 * This keeps ALL proxy logic out of "View Page Source" on the client domain.
 *
 * @package DomainMapper
 */

defined( 'ABSPATH' ) || exit;

class DomainMapper_Form_Interceptor {

    private array $settings;

    public function __construct( array $settings ) {
        $this->settings = $settings;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Public API
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns a single clean external <script> tag.
     * The JS body is served at /dm-interceptor.js by class-proxy.php.
     */
    public function get_script(): string {
        $source = $this->strip_scheme( $this->settings['source_domain'] ?? '' );
        if ( empty( $source ) ) {
            return '';
        }
        return '<script src="http://' . esc_attr( $source ) . '/dm-interceptor.js" defer></script>';
    }

    /**
     * Returns the raw JS interceptor body (no surrounding <script> tags).
     * Called by class-proxy.php to serve /dm-interceptor.js.
     */
    public function get_js_body(): string {
        $source       = $this->strip_scheme( $this->settings['source_domain'] ?? '' );
        // FIX: target_domain is stored as full URL including path
        // e.g. "https://apiserver.ai-landingpages.sharehq.org/api/v1/proxy"
        // TARGET_HOST must be ONLY the hostname for dm-relay routing.
        // strip_scheme() returns "apiserver.ai-landingpages.sharehq.org/api/v1/proxy"
        // which makes the relay POST to /api/v1/proxy/api/leads (wrong path → 404).
        $target_raw   = $this->settings['target_domain'] ?? '';
        $target_host  = (string) wp_parse_url( $target_raw, PHP_URL_HOST );
        if ( empty( $target_host ) ) {
            // fallback: strip scheme then take only up to first slash
            $target_host = (string) preg_replace( '#^https?://#i', '', $target_raw );
            $target_host = (string) strtok( $target_host, '/' );
        }
        $target       = $target_host; // hostname only — e.g. "apiserver.ai-landingpages.sharehq.org"
        $bare         = (string) preg_replace( '/^www\./i', '', $target );
        $relay_prefix = 'http://' . $source . '/dm-relay/';
        $relay_domains = $this->get_relay_domains( $bare );

        $rp  = addslashes( $relay_prefix );
        $rds = wp_json_encode( $relay_domains );
        $sh  = addslashes( $source );
        $th  = addslashes( $target );

        return <<<JS
(function() {
    'use strict';

    var SOURCE_HOST   = '{$sh}';
    var TARGET_HOST   = '{$th}';
    var RELAY_PREFIX  = '{$rp}';
    var RELAY_DOMAINS = {$rds};

    function rewriteUrl(url) {
        if (!url || typeof url !== 'string') return url;
        url = url.replace(/([^:])\/\//g, '\$1/');
        if (
            url.indexOf('data:')     === 0 ||
            url.indexOf('blob:')     === 0 ||
            url.indexOf('dm-relay')  !== -1
        ) return url;

        // Protocol-relative
        if (url.indexOf('//') === 0 && url.indexOf('//' + SOURCE_HOST) === -1) {
            if (url.split('/').length < 4) { url = '/' + url.substring(2); }
        }

        // Root-relative
        if (url.charAt(0) === '/' && url.charAt(1) !== '/') {
            return 'http://' + SOURCE_HOST + '/dm-relay/' + TARGET_HOST + url;
        }

        // Absolute
        try {
            var u = new URL(url, window.location.href);
            for (var i = 0; i < RELAY_DOMAINS.length; i++) {
                if (u.hostname === RELAY_DOMAINS[i] || u.hostname.endsWith('.' + RELAY_DOMAINS[i])) {
                    return 'http://' + SOURCE_HOST + '/dm-relay/' + u.hostname + u.pathname + u.search + u.hash;
                }
            }
            if (u.hostname === SOURCE_HOST) {
                var p = u.pathname;
                if ((p.indexOf('.php') !== -1 || u.search.indexOf('action=') !== -1) && !p.startsWith('/wp-')) {
                    return 'http://' + SOURCE_HOST + '/dm-relay/' + TARGET_HOST + p + u.search + u.hash;
                }
            }
        } catch(e) {}
        return url;
    }

    // Intercept fetch()
    var _origFetch = window.fetch;
    window.fetch = function(input, init) {
        try {
            if (typeof input === 'string') {
                input = rewriteUrl(input);
            } else if (input && input.url) {
                var nu = rewriteUrl(input.url);
                if (nu !== input.url) input = new Request(nu, input);
            }
            init = init || {};
            init.credentials = init.credentials || 'include';
        } catch(e) {}
        return _origFetch.call(this, input, init);
    };

    // Intercept XHR
    var _origXHROpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
        try { url = rewriteUrl(url); } catch(e) {}
        this.withCredentials = true;
        var args = Array.prototype.slice.call(arguments);
        args[1] = url;
        return _origXHROpen.apply(this, args);
    };

    // Intercept sendBeacon
    if (navigator.sendBeacon) {
        var _origBeacon = navigator.sendBeacon.bind(navigator);
        navigator.sendBeacon = function(url, data) { return _origBeacon(rewriteUrl(url), data); };
    }

    // Intercept createElement src/href/action setters
    var _origCE = document.createElement.bind(document);
    document.createElement = function(tag) {
        var el  = _origCE(tag);
        var t   = (tag || '').toLowerCase();
        if (t === 'script' || t === 'link' || t === 'img' || t === 'iframe' || t === 'form') {
            var _origSA = el.setAttribute.bind(el);
            el.setAttribute = function(name, value) {
                if ((name === 'src' || name === 'href' || name === 'action') && typeof value === 'string') {
                    value = rewriteUrl(value);
                }
                return _origSA(name, value);
            };
        }
        return el;
    };

    // Hook prototype src property on img/script/iframe
    try {
        var _hook = function(proto, prop) {
            var orig = Object.getOwnPropertyDescriptor(proto, prop);
            if (!orig) return;
            Object.defineProperty(proto, prop, {
                set: function(v) { orig.set.call(this, rewriteUrl(v)); },
                get: function()  { return orig.get.call(this); },
                configurable: true
            });
        };
        _hook(HTMLImageElement.prototype,  'src');
        _hook(HTMLScriptElement.prototype, 'src');
        _hook(HTMLIFrameElement.prototype,  'src');
    } catch(e) {}

    // Intercept form.submit()
    try {
        var _origSubmit = HTMLFormElement.prototype.submit;
        HTMLFormElement.prototype.submit = function() {
            this.action = rewriteUrl(this.action);
            if (this.action.indexOf('/dm-relay/') !== -1) {
                this.method = 'POST';
            }
            return _origSubmit.apply(this, arguments);
        };
    } catch(e) {}

    // ── Redirect URL normalizer ────────────────────────────────────────────
    // Converts any legacy ?status=thank-you or #slug?status=thank-you URL
    // to a canonical clean path: /slug/thank-you
    function normalizeTyUrl(url) {
        if (!url || typeof url !== 'string') return url;
        // Pattern 1: ?status=thank-you (query string form)
        if (/[?&](status|thankyou|thank_you)=thank[-_]?you/i.test(url)) {
            var base = url.split('?')[0].replace(/\/+$/, '');
            return window.location.origin + new URL(base, window.location.href).pathname + '/thank-you';
        }
        // Pattern 2: #slug?status=thank-you (hash + query-string form)
        var hashMatch = url.match(/#([^?]+)\?.*status.*thank/i);
        if (hashMatch) {
            var slug = hashMatch[1].replace(/^\/+|\/+$/g, '');
            var preHash = url.split('#')[0].replace(/\/+$/, '');
            try {
                var origin = new URL(preHash, window.location.href).origin;
                var base2 = new URL(preHash, window.location.href).pathname.replace(/\/+$/, '');
                return origin + base2 + '/' + slug + '/thank-you';
            } catch(e) {}
            return window.location.origin + window.location.pathname.replace(/\/+$/, '') + '/' + slug + '/thank-you';
        }
        return url;
    }

    // Lead Capture Logic
    async function submitLead(data, form, btn, originalBtnText) {
        try {
            console.log("📡 Sending Lead Data:", data);
            
            // Route through dm-relay to avoid CORS and ensure proxy relaying
            var response = await fetch(RELAY_PREFIX + TARGET_HOST + '/api/leads', {
                method: "POST",
                headers: { 
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },
                body: JSON.stringify(data),
                mode: 'cors'
            });

            var result = await response.json();
            console.log("📥 API Response:", result);

            if (result.status === 'success') {
                form.reset();

                // FIX: Always use window.location.origin to build the thank-you URL.
                // Backend returns redirect as 'http://' but site may force HTTPS.
                // window.location.origin gives correct protocol (https://) + domain.
                // Also normalize any legacy ?status=thank-you URLs to clean paths.
                var tyUrl = '';
                if (result.redirect) {
                    try {
                        var redirectObj = new URL(result.redirect);
                        tyUrl = window.location.origin + redirectObj.pathname;
                    } catch (e) {
                        var tyPath2 = result.redirect.startsWith('/') ? result.redirect : '/' + result.redirect;
                        tyUrl = window.location.origin + tyPath2;
                    }
                    // Normalize any legacy query-string or hash-based thank-you URL
                    tyUrl = normalizeTyUrl(tyUrl);
                } else {
                    var currentPath = window.location.pathname.replace(/\/+$/, '');
                    tyUrl = window.location.origin + currentPath + '/thank-you';
                }
                // Final safety check: ensure it ends with /thank-you
                if (!/\/thank-you\/?$/i.test(new URL(tyUrl).pathname)) {
                    tyUrl = tyUrl.replace(/\/+$/, '') + '/thank-you';
                }
                window.location.href = tyUrl;
            } else {
                // FIX: On error/fail, re-enable the button and show an inline
                // error message. Previously this triggered a redirect to thank-you,
                // which was confusing — user saw "thank you" even when submission failed.
                if (btn) { btn.disabled = false; btn.innerHTML = originalBtnText; }
                var errMsg = result.message || 'Submission failed. Please try again.';
                var errEl = form.querySelector('.dm-form-error') || (function() {
                    var d = document.createElement('p');
                    d.className = 'dm-form-error';
                    d.style.cssText = 'color:red;margin-top:8px;font-size:14px;font-weight:500;';
                    form.appendChild(d);
                    return d;
                })();
                errEl.textContent = errMsg;
                throw new Error(errMsg);
            }
        } catch (err) {
            console.error("❌ Lead Submission Error:", err);
            // Fallback to clean path redirect (never submit the form natively)
            var fallbackPath = window.location.pathname.replace(/\/+$/, '');
            window.location.href = window.location.origin + fallbackPath + '/thank-you';
        }
    }


    // High-priority interceptor for natural form submissions
    document.addEventListener('submit', function(e) {
        var form = e.target;
        if (form && form.tagName === 'FORM') {
            form.method = 'POST';
            form.action = rewriteUrl(form.action);

            // FIX: Previously only intercepted forms with email or name inputs.
            // This silently skipped travel/booking/service forms (date, phone,
            // destination, etc.) — leads were never captured.
            // Now intercept ALL forms that have at least one user-fillable input.
            var hasInputs = form.querySelector(
                'input:not([type="hidden"]):not([type="submit"]):not([type="reset"]):not([type="button"]), select, textarea'
            );

            if (hasInputs) {
                e.preventDefault();
                e.stopImmediatePropagation();
                
                var btn = form.querySelector('button[type="submit"]') || form.querySelector('button');
                var originalText = btn ? btn.innerHTML : 'Submit';
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = 'Sending...';
                }

                var fd = new FormData(form);
                
                // Discover metadata from page if available (injected by backend)
                var pageId = document.querySelector('meta[name="dm-page-id"]')?.content || '';
                var projectId = document.querySelector('meta[name="dm-project-id"]')?.content || '';
                
                // Robust Slug Detection: Handle nested paths
                var pathParts = window.location.pathname.split('/').filter(Boolean);
                var resolvedSlug = pathParts.join('/'); 
                
                var data = {
                    pageId: pageId,
                    projectId: projectId,
                    pageSlug: resolvedSlug,
                    // FIX: Include url + domain so backend can resolve the correct
                    // page even when pageId/projectId meta tags are not injected.
                    url: window.location.href,
                    domain: window.location.hostname,
                    timestamp: new Date().getTime()
                };

                // Capture every named field individually (handles checkboxes, radios, selects)
                form.querySelectorAll('input, select, textarea').forEach(function(el) {
                    if (!el.name) return;
                    var val = el.value ? String(el.value).trim() : '';
                    if (el.type === 'checkbox' || el.type === 'radio') {
                        if (el.checked) data[el.name] = val;
                    } else if (val !== '') {
                        data[el.name] = val;
                    }
                });

                // Also include FormData as a safety net for complex inputs
                fd.forEach(function(v, k) {
                    if (k && v && String(v).trim() !== '' && !data[k]) data[k] = v;
                });

                submitLead(data, form, btn, originalText);
            }
        }
    }, true);

    // Bulletproof: Force POST on click of any submit-like button
    document.addEventListener('click', function(e) {
        var el = e.target;
        if (el && (el.type === 'submit' || el.tagName === 'BUTTON')) {
            var form = el.form || el.closest('form');
            if (form) {
                form.method = 'POST';
                form.action = rewriteUrl(form.action);
            }
        }
    }, true);

    // Initial pass for methods
    function syncMethods() {
        var forms = document.getElementsByTagName('form');
        for (var i = 0; i < forms.length; i++) {
            forms[i].method = 'POST';
        }
    }
    syncMethods();
    setInterval(syncMethods, 2000); // Repeat every 2s for dynamic forms

})();
JS;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────────────────

    private function get_relay_domains( string $bare_domain ): array {
        $domains = [];
        foreach ( [ 'dashboard', 'cdn', 'static', 'assets', 'api', 'app', 'media', 'img' ] as $sub ) {
            $domains[] = $sub . '.' . $bare_domain;
        }
        $extra = $this->settings['extra_relay_domains'] ?? '';
        if ( ! empty( $extra ) ) {
            foreach ( preg_split( '/[\r\n,]+/', $extra ) as $line ) {
                $line = trim( (string) preg_replace( '#^https?://#i', '', $line ) );
                if ( $line !== '' && ! in_array( $line, $domains, true ) ) {
                    $domains[] = $line;
                }
            }
        }
        foreach ( [ 'kxcdn.com', 'cloudfront.net', 'agencyplatform.com', 'edeveloperz.com', 'crazyegg.com' ] as $d ) {
            if ( ! in_array( $d, $domains, true ) ) {
                $domains[] = $d;
            }
        }
        return array_values( array_unique( array_filter( $domains ) ) );
    }

    private function strip_scheme( string $url ): string {
        return (string) preg_replace( '#^https?://#i', '', rtrim( $url, '/' ) );
    }
}
