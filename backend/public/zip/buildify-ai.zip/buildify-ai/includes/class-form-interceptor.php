<?php
/**
 * Form Interceptor.
 *
 * Provides two APIs:
 *   get_script()   — emits a single clean external <script src="..."> tag into the HTML.
 *   get_js_body()  — returns the raw JS body served by class-proxy.php at /dm-interceptor.js.
 *
 * This keeps ALL proxy logic out of "View Page Source" on the client domain.
 *
 * @package DomainMapper
 */

defined('ABSPATH') || exit;

class DomainMapper_Form_Interceptor
{

    private $settings;

    public function __construct($settings)
    {
        $this->settings = $settings;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Public API
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns a single clean external <script> tag.
     * The JS body is served at /dm-interceptor.js by class-proxy.php.
     */
    public function get_script() {
        $source = $this->strip_scheme((isset($this->settings['source_domain']) ? $this->settings['source_domain'] : ''));
        if (empty($source)) {
            return '';
        }
        $v = time(); // Cache-busting to ensure latest JS is loaded
        return '<script src="https://' . esc_attr($source) . '/dm-interceptor.js?v=' . $v . '" defer></script>';
    }

    /**
     * Returns the raw JS interceptor body (no surrounding <script> tags).
     * Called by class-proxy.php to serve /dm-interceptor.js.
     */
    public function get_js_body() {
        $source = $this->strip_scheme((isset($this->settings['source_domain']) ? $this->settings['source_domain'] : ''));
        $target = $this->strip_scheme((isset($this->settings['target_domain']) ? $this->settings['target_domain'] : ''));
        $bare = (string) preg_replace('/^www\./i', '', $target);
        $relay_prefix = 'https://' . $source . '/dm-relay/';
        $relay_domains = $this->get_relay_domains($bare);

        $rp = addslashes($relay_prefix);
        $rds = wp_json_encode($relay_domains);
        $sh = addslashes($source);
        $th = addslashes($target);

        return <<<JS
(function() {
    'use strict';

    var SOURCE_HOST   = '{$sh}';
    var TARGET_HOST   = '{$th}';
    var RELAY_PREFIX  = '{$rp}';
    var RELAY_DOMAINS = {$rds};

    // ── UTM Persistence: Capture on page load ─────────────────────────────
    function captureUTMs() {
        var q = new URLSearchParams(window.location.search);
        // Also try parent frame (if embedded in iframe)
        try {
            if (window.top !== window && window.top.location.search) {
                var pq = new URLSearchParams(window.top.location.search);
                pq.forEach(function(v, k) { if (!q.has(k)) q.append(k, v); });
            }
        } catch(e) {}
        // Also parse hash params (some redirectors put UTMs there)
        if (window.location.hash && window.location.hash.indexOf('?') !== -1) {
            var hq = new URLSearchParams(window.location.hash.split('?')[1]);
            hq.forEach(function(v, k) { if (!q.has(k)) q.append(k, v); });
        }
        var keys = ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','gclid','fbclid','msclkid'];
        var hasUtm = false;
        for (var i = 0; i < keys.length; i++) {
            if (q.get(keys[i])) { hasUtm = true; break; }
        }
        keys.forEach(function(k) {
            try {
                if (hasUtm) {
                    var v = q.get(k);
                    if (v) {
                        sessionStorage.setItem('dm_' + k, v);
                        localStorage.setItem('dm_' + k, v);
                    } else {
                        sessionStorage.removeItem('dm_' + k);
                        localStorage.removeItem('dm_' + k);
                    }
                } else {
                    sessionStorage.removeItem('dm_' + k);
                    localStorage.removeItem('dm_' + k);
                }
            } catch(e) {}
        });
        // Persist referrer on first load
        if (document.referrer) {
            try {
                if (!sessionStorage.getItem('dm_referrer')) {
                    sessionStorage.setItem('dm_referrer', document.referrer);
                }
            } catch(e) {}
            try {
                if (!localStorage.getItem('dm_referrer')) {
                    localStorage.setItem('dm_referrer', document.referrer);
                }
            } catch(e) {}
        }
    }
    captureUTMs();

    function getUTM(k) {
        var v = null;
        try { v = sessionStorage.getItem('dm_' + k) || localStorage.getItem('dm_' + k); } catch(e) {}
        if (!v) {
            var q = new URLSearchParams(window.location.search);
            v = q.get(k);
        }
        return v || '';
    }

    function getReferrer() {
        var ref = '';
        try { ref = sessionStorage.getItem('dm_referrer') || localStorage.getItem('dm_referrer') || ''; } catch(e) {}
        if (!ref) ref = document.referrer || '';
        return ref;
    }

    function rewriteUrl(url) {
        if (!url || typeof url !== 'string') return url;
        url = url.replace(/([^:])\/\//g, '\$1/');
        if (
            url.indexOf('data:')     === 0 ||
            url.indexOf('blob:')     === 0 ||
            url.indexOf('dm-relay')  !== -1
        ) return url;

        // Protocol-relative
        if (url.indexOf('//') === 0 && url.indexOf('//' + SOURCE_HOST) === -1) {
            if (url.split('/').length < 4) { url = '/' + url.substring(2); }
        }

        // Root-relative
        if (url.charAt(0) === '/' && url.charAt(1) !== '/') {
            return 'http://' + SOURCE_HOST + '/dm-relay/' + TARGET_HOST + url;
        }

        // Absolute
        try {
            var u = new URL(url, window.location.href);
            for (var i = 0; i < RELAY_DOMAINS.length; i++) {
                if (u.hostname === RELAY_DOMAINS[i] || u.hostname.endsWith('.' + RELAY_DOMAINS[i])) {
                    return 'http://' + SOURCE_HOST + '/dm-relay/' + u.hostname + u.pathname + u.search + u.hash;
                }
            }
            if (u.hostname === SOURCE_HOST) {
                var p = u.pathname;
                if ((p.indexOf('.php') !== -1 || u.search.indexOf('action=') !== -1) && !p.startsWith('/wp-')) {
                    return 'http://' + SOURCE_HOST + '/dm-relay/' + TARGET_HOST + p + u.search + u.hash;
                }
            }
        } catch(e) {}
        return url;
    }

    // Intercept fetch()
    var _origFetch = window.fetch;
    window.fetch = function(input, init) {
        try {
            if (typeof input === 'string') {
                input = rewriteUrl(input);
            } else if (input && input.url) {
                var nu = rewriteUrl(input.url);
                if (nu !== input.url) input = new Request(nu, input);
            }
            init = init || {};
            init.credentials = init.credentials || 'include';
        } catch(e) {}
        return _origFetch.call(this, input, init);
    };

    // Intercept XHR
    var _origXHROpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
        try { url = rewriteUrl(url); } catch(e) {}
        this.withCredentials = true;
        var args = Array.prototype.slice.call(arguments);
        args[1] = url;
        return _origXHROpen.apply(this, args);
    };

    // Intercept sendBeacon
    if (navigator.sendBeacon) {
        var _origBeacon = navigator.sendBeacon.bind(navigator);
        navigator.sendBeacon = function(url, data) { return _origBeacon(rewriteUrl(url), data); };
    }

    // Intercept createElement src/href/action setters
    var _origCE = document.createElement.bind(document);
    document.createElement = function(tag) {
        var el  = _origCE(tag);
        var t   = (tag || '').toLowerCase();
        if (t === 'script' || t === 'link' || t === 'img' || t === 'iframe' || t === 'form') {
            var _origSA = el.setAttribute.bind(el);
            el.setAttribute = function(name, value) {
                if ((name === 'src' || name === 'href' || name === 'action') && typeof value === 'string') {
                    value = rewriteUrl(value);
                }
                return _origSA(name, value);
            };
        }
        return el;
    };

    // Hook prototype src property on img/script/iframe
    try {
        var _hook = function(proto, prop) {
            var orig = Object.getOwnPropertyDescriptor(proto, prop);
            if (!orig) return;
            Object.defineProperty(proto, prop, {
                set: function(v) { orig.set.call(this, rewriteUrl(v)); },
                get: function()  { return orig.get.call(this); },
                configurable: true
            });
        };
        _hook(HTMLImageElement.prototype,  'src');
        _hook(HTMLScriptElement.prototype, 'src');
        _hook(HTMLIFrameElement.prototype,  'src');
    } catch(e) {}

    // Intercept form.submit()
    try {
        var _origSubmit = HTMLFormElement.prototype.submit;
        HTMLFormElement.prototype.submit = function() {
            this.action = rewriteUrl(this.action);
            if (this.action.indexOf('/dm-relay/') !== -1) {
                this.method = 'POST';
            }
            return _origSubmit.apply(this, arguments);
        };
    } catch(e) {}

    // Lead Capture Logic
    async function submitLead(data, form, btn, originalBtnText) {
        try {
            console.log("📡 Sending Lead Data:", data);
            
            // Route through dm-relay to avoid CORS and ensure proxy relaying
            var response = await fetch(RELAY_PREFIX + TARGET_HOST + '/api/leads', {
                method: "POST",
                headers: { 
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },
                body: JSON.stringify(data),
                mode: 'cors'
            });

            var result = await response.json();
            console.log("📥 API Response:", result);

            if (result.status === 'success') {
                form.reset();
                
                // Smart Redirection: Use backend's suggested redirect if available
                if (result.redirect) {
                    var redir = result.redirect;
                    // If the backend returns a malformed absolute URL or double slashes pointing to the API/Target
                    if (redir.indexOf('apiserver') !== -1 || redir.indexOf(TARGET_HOST) !== -1 || redir.indexOf('//thank-you') !== -1) {
                        var basePath = window.location.pathname.replace(/\/+$/, '');
                        window.location.href = basePath + '/thank-you' + window.location.search;
                    } 
                    // If it's a relative path like "/thank-you"
                    else if (redir.charAt(0) === '/') {
                        var basePath = window.location.pathname.replace(/\/+$/, '');
                        var targetPath = redir.replace(/\/+/g, '/'); // remove double slashes
                        window.location.href = basePath + targetPath + window.location.search;
                    } 
                    // Otherwise, trust the absolute URL (e.g. an external thank you page)
                    else {
                        window.location.href = redir;
                    }
                } else {
                    // Default fallback: Append /thank-you to current landing page URL
                    var basePath = window.location.pathname.replace(/\/+$/, '');
                    window.location.href = basePath + '/thank-you' + window.location.search;
                }
            } else {
                // FIX: On error/fail, re-enable the button and show an inline
                // error message. Previously this triggered a redirect to thank-you,
                // which was confusing — user saw "thank you" even when submission failed.
                if (btn) { btn.disabled = false; btn.innerHTML = originalBtnText; }
                var errMsg = result.message || 'Submission failed. Please try again.';
                var errEl = form.querySelector('.dm-form-error') || (function() {
                    var d = document.createElement('p');
                    d.className = 'dm-form-error';
                    d.style.cssText = 'color:red;margin-top:8px;font-size:14px;font-weight:500;';
                    form.appendChild(d);
                    return d;
                })();
                errEl.textContent = errMsg;
                throw new Error(errMsg);
            }
        } catch (err) {
            console.error("❌ Lead Submission Error:", err);
            // Fallback to traditional submission if AJAX fails
            form.method = 'POST';
            form.action = rewriteUrl(form.action);
            form.submit();
        }
    }

    // High-priority interceptor for natural form submissions
    document.addEventListener('submit', function(e) {
        var form = e.target;
        if (form && form.tagName === 'FORM') {
            form.method = 'POST';
            form.action = rewriteUrl(form.action);

            // FIX: Previously only intercepted forms with email or name inputs.
            // This silently skipped travel/booking/service forms (date, phone,
            // destination, etc.) — leads were never captured.
            // Now intercept ALL forms that have at least one user-fillable input.
            var hasInputs = form.querySelector(
                'input:not([type="hidden"]):not([type="submit"]):not([type="reset"]):not([type="button"]), select, textarea'
            );

            if (hasInputs) {
                e.preventDefault();
                e.stopImmediatePropagation();
                
                var btn = form.querySelector('button[type="submit"]') || form.querySelector('button');
                var originalText = btn ? btn.innerHTML : 'Submit';
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = 'Sending...';
                }

                var fd = new FormData(form);
                
                // Discover metadata from page if available (injected by backend)
                var pageId = document.querySelector('meta[name="dm-page-id"]')?.content || '';
                var projectId = document.querySelector('meta[name="dm-project-id"]')?.content || '';
                
                // Robust Slug Detection: Handle nested paths
                var pathParts = window.location.pathname.split('/').filter(Boolean);
                var resolvedSlug = pathParts.join('/'); 
                
                var data = {
                    pageId: pageId,
                    projectId: projectId,
                    pageSlug: resolvedSlug,
                    // FIX: Include url + domain so backend can resolve the correct
                    // page even when pageId/projectId meta tags are not injected.
                    url: window.location.href,
                    domain: window.location.hostname,
                    referrer: getReferrer(),
                    timestamp: new Date().getTime(),
                    trackingDetails: {
                        referral_url: window.location.href,
                        referral_source: getReferrer() || 'Direct'
                    }
                };

                // Capture every named field individually (handles checkboxes, radios, selects)
                form.querySelectorAll('input, select, textarea').forEach(function(el) {
                    if (!el.name) return;
                    var val = el.value ? String(el.value).trim() : '';
                    if (el.type === 'checkbox' || el.type === 'radio') {
                        if (el.checked) data[el.name] = val;
                    } else if (val !== '') {
                        data[el.name] = val;
                    }
                });

                // Also include FormData as a safety net for complex inputs
                fd.forEach(function(v, k) {
                    if (k && v && String(v).trim() !== '' && !data[k]) data[k] = v;
                });

                // UTM capture from URL query string (persisted via sessionStorage)
                var utmKeys = ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','gclid','fbclid','msclkid'];
                utmKeys.forEach(function(k) {
                    var val = getUTM(k);
                    if (val) data[k] = val;
                });

                console.log('📡 [DM-Interceptor] Final Lead Data:', data);
                submitLead(data, form, btn, originalText);
            }
        }
    }, true);

    // Bulletproof: Force POST on click of any submit-like button
    document.addEventListener('click', function(e) {
        var el = e.target;
        if (el && (el.type === 'submit' || el.tagName === 'BUTTON')) {
            var form = el.form || el.closest('form');
            if (form) {
                form.method = 'POST';
                form.action = rewriteUrl(form.action);
            }
        }
    }, true);

    // Initial pass for methods
    function syncMethods() {
        var forms = document.getElementsByTagName('form');
        for (var i = 0; i < forms.length; i++) {
            forms[i].method = 'POST';
        }
    }
    syncMethods();
    setInterval(syncMethods, 2000); // Repeat every 2s for dynamic forms

})();
JS;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────────────────

    private function get_relay_domains($bare_domain) {
        $domains = [];
        foreach (['dashboard', 'cdn', 'static', 'assets', 'api', 'app', 'media', 'img'] as $sub) {
            $domains[] = $sub . '.' . $bare_domain;
        }
        $extra = (isset($this->settings['extra_relay_domains']) ? $this->settings['extra_relay_domains'] : '');
        if (!empty($extra)) {
            foreach (preg_split('/[\r\n,]+/', $extra) as $line) {
                $line = trim((string) preg_replace('#^https?://#i', '', $line));
                if ($line !== '' && !in_array($line, $domains, true)) {
                    $domains[] = $line;
                }
            }
        }
        foreach (['kxcdn.com', 'cloudfront.net', 'agencyplatform.com', 'edeveloperz.com', 'crazyegg.com'] as $d) {
            if (!in_array($d, $domains, true)) {
                $domains[] = $d;
            }
        }
        return array_values(array_unique(array_filter($domains)));
    }

    private function strip_scheme($url) {
        return (string) preg_replace('#^https?://#i', '', rtrim($url, '/'));
    }
}