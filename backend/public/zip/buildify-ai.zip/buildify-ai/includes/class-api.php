<?php
/**
 * API subsystem.
 *
 * Handles all communication with the remote SaaS verification endpoint.
 *
 * @package DomainMapper
 */

defined('ABSPATH') || exit;

class DomainMapper_API
{

    private $settings;
    private $cache;
    const TIMEOUT = 15;

    public function __construct($settings, $cache)
    {
        $this->settings = $settings;
        $this->cache = $cache;
    }

    public function verify($force = false) {
        $token = (isset($this->settings['api_key']) ? $this->settings['api_key'] : '');

        if (empty($token)) {
            return $this->error_result(__('API Key is required.', 'domain-mapper'));
        }

        // ── Dynamic Token Logic ──
        $raw = $token;
        if (strpos($token, '@@') === false) {
            $decoded = base64_decode($token, true);
            if ($decoded && strpos($decoded, '@@') !== false) {
                $raw = $decoded;
            }
        }

        // Use the hardcoded backend URL for this project if no custom endpoint is provided in the key.
        if (strpos($raw, '@@') === false) {
            $endpoint = DM_API_BASE . '/plugin/verify';
            $api_key = $raw;
        } else {
            list($endpoint, $api_key) = explode('@@', $raw, 2);
            // Map legacy /plugin/verify if provided in string
            if (false === strpos($endpoint, '/plugin/verify')) {
                $endpoint = rtrim($endpoint, '/') . '/plugin/verify';
            }
        }

        $endpoint = esc_url_raw($endpoint);

        // Automatically use current host if not configured.
        $domain = empty($this->settings['source_domain']) ? ((isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '')) : $this->settings['source_domain'];

        if (empty($api_key) || empty($domain)) {
            return $this->error_result(__('API Key and Domain are required.', 'domain-mapper'));
        }

        // Cache check.
        if (!$force) {
            $cached = $this->cache->get_api($token);
            if (is_array($cached)) {
                return $this->parse_response($cached);
            }
        }

        $response = wp_remote_post(
            $endpoint,
            [
                'timeout' => self::TIMEOUT,
                'user-agent' => 'SiteAccelerator/' . DM_VERSION . '; ' . home_url(),
                'sslverify' => false, // Disabled for local testing environments
                'body' => [
                    'api_key' => sanitize_text_field($api_key),
                    'domain' => sanitize_text_field($domain),
                ],
                'headers' => [
                    'Accept' => 'application/json',
                    'X-DM-Version' => DM_VERSION,
                ],
            ]
        );

        if (is_wp_error($response)) {
            $msg = $response->get_error_message();
            DomainMapper_Loader::log('API error: ' . $msg, true);
            $this->mark_inactive($msg);
            return $this->error_result($msg);
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($code !== 200) {
            $data = json_decode($body, true);
            $msg = (!empty($data['message'])) ? (string) $data['message'] : 'Invalid API Key';
            $this->mark_inactive($msg);
            return $this->error_result($msg);
        }

        $data = json_decode($body, true);
        if (!is_array($data)) {
            return $this->error_result('Invalid server response');
        }

        $result = $this->parse_response($data);

        if ($result['ok']) {
            $ttl = max(60, (int) ((isset($data['cache_time']) ? $data['cache_time'] : 300)));
            $this->cache->set_api($token, $data, $ttl);
            $this->update_options($data, $domain);
        } else {
            $this->mark_inactive($result['message']);
        }

        return $result;
    }

    public function sync() {
        $this->verify(true);
    }

    public function is_active() {
        return 'active' === ((isset($this->settings['status']) ? $this->settings['status'] : ''));
    }

    private function parse_response($data) {
        $status = sanitize_key((isset($data['status']) ? $data['status'] : ''));
        if ('active' !== $status) {
            return $this->error_result('License is not active');
        }

        return [
            'ok' => true,
            'message' => 'License active.',
            'data' => $data,
        ];
    }

    private function error_result($message, $data = []) {
        return ['ok' => false, 'message' => $message, 'data' => $data];
    }

    private function update_options($data, $current_domain = '') {
        $stored = get_option(DM_OPTION, []);
        $stored = is_array($stored) ? $stored : [];

        $current_domain = $current_domain ?: ((isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : ''));

        $stored['status'] = 'active';
        $stored['plan'] = sanitize_text_field((isset($data['plan']) ? $data['plan'] : ''));
        $stored['cache_time'] = max(60, (int) ((isset($data['cache_time']) ? $data['cache_time'] : 300)));
        $stored['last_verified'] = time();
        $stored['verified_domain'] = $current_domain;

        // Source domain (DomainA).
        if (!empty($data['source_url'])) {
            $stored['source_domain'] = (string) preg_replace('#^https?://#i', '', rtrim($data['source_url'], '/'));
        }

        // Target domain (DomainB).
        if (!empty($data['target_url'])) {
            $stored['target_domain'] = (string) rtrim($data['target_url'], '/');
        }

        // Allowed paths.
        if (isset($data['allowed_paths'])) {
            $paths = is_array($data['allowed_paths']) ? implode("\n", $data['allowed_paths']) : (string) $data['allowed_paths'];
            $prev = (isset($stored['allowed_paths']) ? $stored['allowed_paths'] : '');
            $stored['allowed_paths'] = sanitize_textarea_field($paths);

            if ($stored['allowed_paths'] !== $prev) {
                // Write .htaccess immediately — not deferred to shutdown
                DomainMapper_Loader::write_htaccess();

                // Purge nginx cached 404s for ALL allowed paths (not just new ones).
                $all_paths = is_array($data['allowed_paths'])
                    ? $data['allowed_paths']
                    : preg_split('/[\r\n,]+/', $paths);
                if (method_exists('DomainMapper_Loader', 'purge_nginx_cache_for_paths')) {
                    DomainMapper_Loader::purge_nginx_cache_for_paths( array_filter( $all_paths ) );
                }
            }
        }

        $this->settings = $stored;
        update_option(DM_OPTION, $stored, 'no');
    }

    private function mark_inactive($reason) {
        $stored = get_option(DM_OPTION, []);
        $stored['status'] = 'inactive';
        $stored['last_error'] = $reason;
        update_option(DM_OPTION, $stored, 'no');
    }
}
