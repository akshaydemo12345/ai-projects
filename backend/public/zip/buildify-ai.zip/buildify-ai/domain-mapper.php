<?php
/**
 * Plugin Name:       Buildify AI
 * Plugin URI:        https://your-saas.com
 * Description:       Maps DomainA → DomainB via reverse proxy, keeping DomainB URL in browser.
 * Version:           1.1.0
 * Requires at least: 5.0
 * Requires PHP:      5.6
 * Author:            Your SaaS Company
 * License:           Proprietary
 * Text Domain:       domain-mapper
 *
 * @package DomainMapper
 */

defined( 'ABSPATH' ) || exit;

// ── PHP Version Guard ─────────────────────────────────────────────────────────
// Gracefully block activation on PHP < 5.6 instead of crashing the server.
if ( version_compare( PHP_VERSION, '5.6.0', '<' ) ) {
    if ( defined( 'WP_ADMIN' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p><strong>Buildify AI</strong> requires PHP 5.6 or higher. Your server runs PHP ' . PHP_VERSION . '. Please upgrade PHP to use this plugin.</p></div>';
        } );
    }
    return; // Do not load the rest of the plugin.
}

// ── PHP 8.0 Function Polyfills ─────────────────────────────────────────────────
// Provides str_starts_with / str_ends_with / str_contains for PHP < 8.0.
if ( ! function_exists( 'str_starts_with' ) ) {
    function str_starts_with( $haystack, $needle ) {
        return $needle !== '' ? strpos( $haystack, $needle ) === 0 : true;
    }
}
if ( ! function_exists( 'str_ends_with' ) ) {
    function str_ends_with( $haystack, $needle ) {
        return $needle !== '' ? substr( $haystack, -strlen( $needle ) ) === $needle : true;
    }
}
if ( ! function_exists( 'str_contains' ) ) {
    function str_contains( $haystack, $needle ) {
        return $needle !== '' ? strpos( $haystack, $needle ) !== false : true;
    }
}

define( 'DM_VERSION',      '1.1.0' );
define( 'DM_FILE',         __FILE__ );
define( 'DM_DIR',          plugin_dir_path( __FILE__ ) );
define( 'DM_URL',          plugin_dir_url( __FILE__ ) );
define( 'DM_OPTION',       'dm_settings' );
define( 'DM_LOG_FILE',     WP_CONTENT_DIR . '/dm-debug.log' );
define( 'DM_API_BASE',     'https://apiserver.ai-landingpages.sharehq.org' );

require_once DM_DIR . 'includes/class-cache.php';
require_once DM_DIR . 'includes/class-api.php';
require_once DM_DIR . 'includes/class-auto-detect.php';
require_once DM_DIR . 'includes/class-rewriter.php';
require_once DM_DIR . 'includes/class-proxy.php';
require_once DM_DIR . 'includes/class-form-interceptor.php';
require_once DM_DIR . 'admin/settings-page.php';

register_activation_hook( DM_FILE,   [ 'DomainMapper_Loader', 'activate' ] );
register_deactivation_hook( DM_FILE, [ 'DomainMapper_Loader', 'deactivate' ] );
add_action( 'plugins_loaded', [ 'DomainMapper_Loader', 'init' ] );

final class DomainMapper_Loader {

    private static $instance = null;
    public $api;
    public $proxy;
    public $rewriter;
    public $cache;
    private $settings = [];

    // ── Activation ────────────────────────────────────────────────────────────

    public static function activate() {
        $defaults = [
            'api_key'       => '',
            'source_domain' => '',
            'target_domain' => '',
            'cache_time'    => 300,
            'plan'          => '',
            'status'        => 'inactive',
            'debug_mode'    => false,
            'last_verified' => 0,
        ];
        if ( ! get_option( DM_OPTION ) ) {
            // Auto-populate with detected values before saving
            $defaults = DomainMapper_AutoDetect::auto_populate( $defaults );
            add_option( DM_OPTION, $defaults, '', 'no' );
        }

        // Auto-apply .htaccess rules on activation
        self::write_htaccess();

        // NOTE: We intentionally do NOT write .htaccess rules or register a
        // global catch-all rewrite rule on activation.  Doing so broke Divi
        // Builder and every other aspect of the live site before the admin had
        // a chance to configure anything.  Rewrite rules are only injected
        // via the admin "Apply .htaccess" button once specific paths are set.

        if ( ! wp_next_scheduled( 'dm_hourly_sync' ) ) {
            wp_schedule_event( time(), 'hourly', 'dm_hourly_sync' );
        }

        // Register and flush WP rewrite rules on activation so Nginx routes
        // /dm-interceptor.js and /dm-relay/* through WordPress immediately.
        add_rewrite_rule( '^dm-interceptor\.js$', 'index.php?dm_proxy=1', 'top' );
        add_rewrite_rule( '^dm-relay/(.*)$',      'index.php?dm_proxy=1', 'top' );
        flush_rewrite_rules( false ); // false = skip .htaccess regeneration on Nginx

        self::log( 'Plugin activated.', true );
    }

    public static function deactivate() {
        wp_clear_scheduled_hook( 'dm_hourly_sync' );
        DomainMapper_Cache::flush_all();
        // Only restore .htaccess if our block is present (i.e. admin applied it).
        self::restore_htaccess();
        flush_rewrite_rules();

        // Remove all settings on deactivation as per user requirement.
        delete_option( DM_OPTION );

        self::log( 'Plugin deactivated. Settings wiped.', true );
    }

    // ── .htaccess management ──────────────────────────────────────────────────

    /**
     * Inject Domain Mapper rewrite rules into the root .htaccess.
     *
     * Rules are scoped to the configured allowed_paths only.
     * Everything else (Divi Builder, REST API, uploads, themes, etc.)
     * is left completely untouched.
     */
    public static function write_htaccess() {
        $htaccess = ABSPATH . '.htaccess';

        // Build per-path RewriteRules from the allowed_paths setting.
        $settings = get_option( DM_OPTION, [] );
        $raw_paths = (isset($settings['allowed_paths']) ? $settings['allowed_paths'] : '');
        $path_rules = '';
        
        if ( ! empty( $raw_paths ) ) {
            // Specific paths configured — create rules for each
            foreach ( preg_split( '/[\r\n,]+/', $raw_paths ) as $line ) {
                $line = trim( $line );
                if ( $line !== '' ) {
                    $is_wildcard = false;
                    if ( (substr($line, -strlen('/*')) === '/*') ) {
                        $is_wildcard = true;
                        $line = rtrim( substr( $line, 0, -2 ), '/' );
                    }

                    $line = trim( $line, '/\\s' );
                    $escaped = preg_quote( $line, '#' );

                    if ( $is_wildcard ) {
                        $path_rules .= "    RewriteRule ^{$escaped}(/.*)?$ index.php [QSA,L]\n";
                    } else {
                        // Allow sub-paths like /thank-you to route properly
                        $path_rules .= "    RewriteRule ^{$escaped}(/.*)?$ index.php [QSA,L]\n";
                    }
                }
            }
        }

        if ( empty( $path_rules ) ) {
            // No specific paths — NO global rules. 
            // This prevents the plugin from breaking the site before paths are synced.
            $path_rules = "    # No paths configured yet. Site runs normally.\n";
        }

        $dm_block = <<<HTACCESS
# BEGIN DomainMapper
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /

    # ── 1. Always serve WordPress core & admin paths directly ────────────
    RewriteRule ^wp-admin(/.*)?$                        -   [L]
    RewriteRule ^wp-login\.php                          -   [L]
    RewriteRule ^wp-cron\.php                           -   [L]
    RewriteRule ^xmlrpc\.php                            -   [L]
    RewriteRule ^wp-includes/(.*)$                      -   [L]

    # ── 2. Always serve this plugin's own files directly ─────────────────
    RewriteRule ^wp-content/plugins/(.*)$               -   [L]

    # ── 3. Always serve themes, uploads and other wp-content directly ─────
    RewriteRule ^wp-content/(.*)$                       -   [L]

    # ── 4. Route proxy paths through index.php ────────────────────────────
$path_rules
</IfModule>
# END DomainMapper
HTACCESS;

        if ( ! file_exists( $htaccess ) ) {
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
            file_put_contents( $htaccess, $dm_block . "\n" );
            self::log( '.htaccess created with path-specific rules.', true );
            return;
        }

        $current = file_get_contents( $htaccess );

        // Already has our block — replace it.
        if ( strpos( $current, '# BEGIN DomainMapper' ) !== false ) {
            $current = preg_replace(
                '#\# BEGIN DomainMapper.*?\# END DomainMapper\s*#s',
                $dm_block . "\n",
                $current
            );
        } else {
            // Prepend before the WordPress block so DM rules win.
            $current = $dm_block . "\n" . $current;
        }

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        file_put_contents( $htaccess, $current );
        self::log( '.htaccess updated with path-specific rules.', true );
        
        flush_rewrite_rules(); // Ensure WP rewrite rules are also flushed
    }

    /**
     * Remove the DomainMapper block from .htaccess on deactivation.
     */
    public static function restore_htaccess() {
        $htaccess = ABSPATH . '.htaccess';
        if ( ! file_exists( $htaccess ) ) {
            return;
        }
        $current = file_get_contents( $htaccess );
        if ( strpos( $current, '# BEGIN DomainMapper' ) === false ) {
            return; // Nothing to remove.
        }
        $cleaned = preg_replace(
            '#\# BEGIN DomainMapper.*?\# END DomainMapper\s*#s',
            '',
            $current
        );
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        file_put_contents( $htaccess, $cleaned );
        self::log( '.htaccess restored.', true );
    }

    // ── nginx cache purge ─────────────────────────────────────────────────────

    public static function purge_nginx_cache_for_paths($paths) {
        $base = home_url();

        foreach ($paths as $path) {
            $path = '/' . ltrim(trim((string) $path), '/');
            if (empty($path) || $path === '/')
                continue;

            $url = rtrim($base, '/') . $path;

            wp_remote_get($url, [
                'timeout' => 3,
                'blocking' => false,
                'sslverify' => false,
                'headers' => [
                    'Cache-Control' => 'no-cache, no-store, must-revalidate',
                    'Pragma' => 'no-cache',
                    'X-DM-Purge' => '1',
                ],
                'user-agent' => 'DomainMapper-CachePurge/' . DM_VERSION,
            ]);

            self::log("Cache purge request sent: {$url}", true);
        }
    }

    public static function pre_warm_all_paths() {
        $settings = get_option(DM_OPTION, []);
        $raw_paths = (isset($settings['allowed_paths']) ? $settings['allowed_paths'] : '');
        if (empty($raw_paths))
            return;

        $paths = array_filter(preg_split('/[\r\n,]+/', $raw_paths));
        $base = home_url();

        foreach ($paths as $path) {
            $path = '/' . ltrim(trim((string) $path), '/');
            if (empty($path) || $path === '/')
                continue;

            $url = rtrim($base, '/') . $path;

            // BLOCKING request so we get the response — this warms the cache.
            wp_remote_get($url, [
                'timeout' => 8,
                'blocking' => true,
                'sslverify' => false,
                'headers' => [
                    'Cache-Control' => 'no-cache, no-store, must-revalidate',
                    'Pragma' => 'no-cache',
                    'X-DM-Prewarm' => '1',
                ],
                'user-agent' => 'DomainMapper-PreWarm/' . DM_VERSION,
            ]);

            self::log("Pre-warm request sent: {$url}", true);
        }
    }

    // ── Bootstrap ─────────────────────────────────────────────────────────────

    public static function init() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->check_domain_change();
        }
    }

    /**
     * Automatically detect domain change and reset verification if needed.
     */
    private function check_domain_change() {
        if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
            return;
        }

        $current_host = sanitize_text_field( (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : ''));
        $stored_host  = (isset($this->settings['verified_domain']) ? $this->settings['verified_domain'] : '');

        if ( ! empty( $stored_host ) && $current_host !== $stored_host ) {
             self::log( "Domain change detected: {$stored_host} -> {$current_host}. Resetting verification.", true );
             $this->settings['status'] = 'inactive';
             $this->settings['verified_domain'] = '';
             update_option( DM_OPTION, $this->settings );
        }

        // Auto-verify in background if inactive or time elapsed (e.g. 24h)
        $last_v = (int) ( (isset($this->settings['last_verified']) ? $this->settings['last_verified'] : 0));
        if ( $this->settings['status'] !== 'active' || ( time() - $last_v ) > DAY_IN_SECONDS ) {
            if ( ! empty( $this->settings['api_key'] ) ) {
                // We use a non-blocking check or just do it once per hour via cron, 
                // but for "auto-background" on init, we can do it if status is inactive.
                if ( $this->settings['status'] !== 'active' ) {
                   $this->api->verify( true );
                }
            }
        }
    }

    public static function instance() {
        return self::$instance;
    }

    private function __construct() {
        $this->settings = $this->load_settings();
        $this->cache    = new DomainMapper_Cache( $this->settings );
        $this->api      = new DomainMapper_API( $this->settings, $this->cache );
        $this->rewriter = new DomainMapper_Rewriter( $this->settings );
        $this->proxy    = new DomainMapper_Proxy( $this->settings, $this->cache, $this->rewriter, $this->api );

        $this->register_hooks();
    }

    private function load_settings() {
        $defaults = [
            'api_key'         => '',
            'source_domain'   => '',
            'target_domain'   => '',
            'cache_time'      => 300,
            'plan'            => '',
            'status'          => 'inactive',
            'debug_mode'      => false,
            'last_verified'   => 0,
            'allowed_paths'   => '',
            'verified_domain' => '',
        ];
        $stored = get_option( DM_OPTION, [] );
        return wp_parse_args( is_array( $stored ) ? $stored : [], $defaults );
    }

    private function register_hooks() {
        // Admin.
        if ( is_admin() ) {
            $admin = new DomainMapper_Settings_Page( $this->settings, $this->api );
            add_action( 'admin_menu',            [ $admin, 'register_menu' ] );
            add_action( 'admin_init',            [ $admin, 'register_settings' ] );
            add_action( 'admin_notices',         [ $admin, 'admin_notices' ] );
            add_action( 'admin_enqueue_scripts', [ $admin, 'enqueue_scripts' ] );
            // Button to re-apply htaccess.
            add_action( 'wp_ajax_dm_rewrite_htaccess', [ $this, 'ajax_rewrite_htaccess' ] );
            add_action( 'wp_ajax_dm_prewarm_paths', [ $this, 'ajax_prewarm_paths' ] );
        }

        // REST API for remote cache flushing.
        add_action( 'rest_api_init', [ $this, 'register_rest_routes' ] );

        // Proxy — priority 1, before anything else.
        // The proxy's intercept() checks is_path_allowed() internally and
        // returns early when no paths are configured, so it is safe to register
        // unconditionally here.
        add_action( 'init', [ $this->proxy, 'intercept' ], 1 );
        add_action( 'template_redirect', [ $this->proxy, 'maybe_proxy_404' ] );

        // Only disable canonical redirects for paths that are actively proxied.
        // This prevents disrupting Divi Builder and native WP pages.
        add_filter( 'redirect_canonical', [ $this, 'maybe_disable_canonical' ], 1 );

        // Only bypass 404 handling for paths that are actively proxied.
        add_filter( 'pre_handle_404', [ $this, 'maybe_bypass_404' ], 1, 2 );

        // NOTE: We do NOT register a global catch-all rewrite rule.
        // A catch-all ^(.+)/?$ → index.php intercepts every page including
        // Divi Builder AJAX requests and core WP REST endpoints.  The proxy
        // works correctly at the PHP level via the 'init' hook above.

        // Cron.
        add_action( 'dm_hourly_sync', [ $this->api, 'sync' ] );

        // i18n.
        add_action( 'init', [ $this, 'load_textdomain' ] );
        
        // WP Rewrite Rules for Nginx
        add_action( 'init', [ $this, 'register_wp_rewrite_rules' ] );
    }

    /**
     * Disable canonical redirects when proxy is active.
     *
     * @param  string|false $redirect_url
     * @return string|false
     */
    public function maybe_disable_canonical( $redirect_url ) {
        $uri = (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/');
        // Only suppress canonical redirect for paths the proxy will actually serve.
        if ( ! is_admin() && $this->proxy->is_proxied_path( $uri ) ) {
            return false;
        }
        return $redirect_url;
    }

    /**
     * Prevent WordPress from showing its 404 page for unknown paths.
     * Only applicable to paths that the proxy is configured to handle.
     *
     * @param  bool      $bypass
     * @param  \WP_Query $q
     * @return bool
     */
    public function maybe_bypass_404( $bypass, $q ) {
        $uri = (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/');
        // FIX: Use is_path_in_allowed() directly — not is_proxied_path() which
        // also calls is_existing_content() and wrongly blocks WP pages sharing
        // the same slug as a configured proxy path.
        if ( ! is_admin() && $this->proxy->is_path_in_allowed( $uri ) ) {
            return true;
        }
        return $bypass;
    }

    /** AJAX: re-apply .htaccess rules without deactivating the plugin. */
    public function ajax_rewrite_htaccess() {
        check_ajax_referer( 'dm_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error();
        }
        self::write_htaccess();
        wp_send_json_success( [ 'message' => '.htaccess updated successfully.' ] );
    }

    /** AJAX: Pre-warm all proxy paths to clear GoDaddy / nginx cached 404s. */
    public function ajax_prewarm_paths() {
        check_ajax_referer('dm_admin_nonce', 'nonce');
        if (!current_user_can('manage_options'))
            wp_send_json_error();
        if (!empty($this->settings['api_key'])) {
            $this->api->sync();
        }
        self::pre_warm_all_paths();
        wp_send_json_success(['message' => 'All proxy paths pre-warmed. New pages should now load without 404.']);
    }

    /**
     * Register proxy paths as WordPress rewrite rules.
     * This is essential for Nginx servers which ignore .htaccess.
     */
    public function register_wp_rewrite_rules() {
        // ── Always-required routes (Nginx ignores .htaccess) ───────────────────
        // These must be registered regardless of whether any proxy paths are set.
        add_rewrite_rule( '^dm-interceptor\.js$',     'index.php?dm_proxy=1', 'top' );
        add_rewrite_rule( '^dm-relay/(.*)$',           'index.php?dm_proxy=1', 'top' );

        // ── Per-path rules from allowed_paths setting ──────────────────────────
        $raw_paths = (isset($this->settings['allowed_paths']) ? $this->settings['allowed_paths'] : '');
        if ( ! empty( $raw_paths ) ) {
            foreach ( preg_split( '/[\r\n,]+/', $raw_paths ) as $line ) {
                $line = trim( $line );
                if ( $line !== '' ) {
                    $is_wildcard = false;
                    if ( (substr($line, -strlen('/*')) === '/*') ) {
                        $is_wildcard = true;
                        $line = rtrim( substr( $line, 0, -2 ), '/' );
                    }
                    $line = trim( $line, '/\s' );
                    $escaped = preg_quote( $line, '#' );

                    if ( $is_wildcard ) {
                        add_rewrite_rule( "^{$escaped}(/.*)?$", 'index.php?dm_proxy=1', 'top' );
                    } else {
                        // Also allow all sub-paths (e.g. /slug/thank-you)
                        add_rewrite_rule( "^{$escaped}(/.*)?$", 'index.php?dm_proxy=1', 'top' );
                    }
                }
            }
        }

        // ── Flush rewrite rules if our rules are not yet in WP's DB ───────────
        // This auto-flushes once without requiring admin to visit Settings > Permalinks.
        $stored_rules = get_option( 'rewrite_rules', [] );
        if ( ! is_array( $stored_rules ) || ! isset( $stored_rules['dm-interceptor\.js$'] ) ) {
            flush_rewrite_rules( false ); // false = don't regenerate .htaccess (Nginx site)
        }
    }

    /** ── REST API ───────────────────────────────────────────────────────────── */

    public function register_rest_routes() {
        register_rest_route( 'domain-mapper/v1', '/flush', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'rest_flush_cache' ],
            'permission_callback' => [ $this, 'check_rest_permission' ],
        ] );
    }

    /**
     * Verify that the request comes from our backend using the API key.
     */
    public function check_rest_permission( $request ) {
        $header_key = $request->get_header( 'X-DM-API-Key' );
        $stored_key = (isset($this->settings['api_key']) ? $this->settings['api_key'] : '');

        if ( empty( $stored_key ) ) {
            return false;
        }

        // Exact match of the configured API key.
        return hash_equals( $stored_key, (string) $header_key );
    }

    /**
     * Trigger a full cache flush.
     */
    public function rest_flush_cache( $request ) {
        DomainMapper_Cache::flush_all();
        self::log( 'REST: Full cache flush triggered by backend.', true );

        return new \WP_REST_Response( [
            'ok'      => true,
            'message' => __( 'Cache flushed successfully.', 'domain-mapper' ),
        ], 200 );
    }

    public function load_textdomain() {
        load_plugin_textdomain( 'domain-mapper', false, dirname( plugin_basename( DM_FILE ) ) . '/languages' );
    }

    public static function log( $message, $force = false ) {
        $settings = get_option( DM_OPTION, [] );
        if ( empty( $settings['debug_mode'] ) && ! $force ) {
            return;
        }
        $entry = sprintf( "[%s] %s\n", gmdate( 'Y-m-d H:i:s' ), $message );
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        file_put_contents( DM_LOG_FILE, $entry, FILE_APPEND | LOCK_EX );
    }
}
