'use strict';

const axios = require('axios');
const cheerio = require('cheerio');
const logger = require('../utils/logger');

/**
 * Fetches and extracts metadata from a website URL.
 * Used for "Quick Inspect" before generating a page.
 */
const inspectWebsite = async (url) => {
  try {
    const response = await axios.get(url, {
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      }
    });

    const $ = cheerio.load(response.data);
    const urlObj = new URL(url);

    // 1. Basic SEO
    const title = $('title').text().trim() || $('meta[property="og:title"]').attr('content') || '';
    const description = $('meta[name="description"]').attr('content') || $('meta[property="og:description"]').attr('content') || '';
    
    // 2. Favicon
    let favicon = $('link[rel="shortcut icon"]').attr('href') || 
                  $('link[rel="icon"]').attr('href') || 
                  $('link[rel="apple-touch-icon"]').attr('href');
    if (favicon && !favicon.startsWith('http')) {
      favicon = new URL(favicon, url).href;
    } else if (!favicon) {
      favicon = `${urlObj.origin}/favicon.ico`;
    }

    // 3. Logo Detection
    let logo = $('meta[property="og:image"]').attr('content') || '';
    if (!logo) {
      // Look for images with "logo" in class or alt
      const logoImg = $('img[alt*="logo" i], img[class*="logo" i], img[src*="logo" i]').first();
      if (logoImg.length) {
        logo = logoImg.attr('src');
      }
    }
    if (logo && !logo.startsWith('http')) {
      logo = new URL(logo, url).href;
    }

    // 4. Color Extraction (Heuristic)
    const suggestedColors = [];
    const themeColor = $('meta[name="theme-color"]').attr('content');
    if (themeColor) suggestedColors.push(themeColor);

    // Look for background colors in inline styles of main elements
    $('[style*="background-color"]').slice(0, 5).each((i, el) => {
      const style = $(el).attr('style');
      const match = style.match(/background-color:\s*(#[a-fA-F0-0]{3,6}|rgb\([^)]+\))/);
      if (match && !suggestedColors.includes(match[1])) suggestedColors.push(match[1]);
    });

    // 5. Fonts
    const fonts = [];
    $('link[href*="fonts.googleapis.com"], link[href*="fonts.gstatic.com"]').each((i, el) => {
      const href = $(el).attr('href');
      const match = href.match(/family=([^&:]+)/);
      if (match) fonts.push(match[1].replace(/\+/g, ' '));
    });

    // 6. Main Content (for AI context)
    const bodyText = $('body').clone();
    bodyText.find('script, style, nav, footer, noscript, iframe, svg').remove();
    const cleanText = bodyText.text().replace(/\s+/g, ' ').trim().substring(0, 5000);

    // 7. Social Links
    const socialLinks = {};
    $('a[href*="facebook.com"], a[href*="twitter.com"], a[href*="linkedin.com"], a[href*="instagram.com"]').each((i, el) => {
      const href = $(el).attr('href');
      if (href.includes('facebook.com')) socialLinks.facebook = href;
      if (href.includes('twitter.com') || href.includes('x.com')) socialLinks.twitter = href;
      if (href.includes('linkedin.com')) socialLinks.linkedin = href;
      if (href.includes('instagram.com')) socialLinks.instagram = href;
    });

    return {
      url,
      title,
      description,
      favicon,
      logo,
      fonts: [...new Set(fonts)],
      suggestedColors: [...new Set(suggestedColors)],
      socialLinks,
      rawContent: cleanText
    };
  } catch (err) {
    logger.error(`Scraping failed for ${url}: ${err.message}`);
    throw new Error(`Failed to access website: ${err.message}`);
  }
};

/**
 * Analyzes a website and returns AI-generated landing page options.
 * This is the full generation step.
 */
const analyzeWebsite = async (websiteUrl) => {
  const metadata = await inspectWebsite(websiteUrl);
  const aiHelper = require('./aiService');

  const prompt = `
    Analyze the following metadata extracted from ${websiteUrl} and create a PREMIUM, high-converting landing page.
    
    WEBSITE METADATA:
    Title: ${metadata.title}
    Description: ${metadata.description}
    Detected Fonts: ${metadata.fonts.join(', ')}
    Main Content: ${metadata.rawContent}
    
    DIRECTIONS:
    1. Extract the essence of their brand (colors, tone, value proposition).
    2. Create an improved structure that follows current 2026 SaaS/Service landing page trends.
    3. Use their existing content as context but rewrite everything for maximum conversion.
    4. MUST return a JSON with fullHtml and fullCss.
  `;

  return await aiHelper.generateLandingPageContent({
    businessName: metadata.title.split('|')[0].trim(),
    industry: 'Business Service',
    pageType: 'lead generation',
    businessDescription: metadata.description || metadata.rawContent.substring(0, 200),
    logoUrl: metadata.logo,
    aiPrompt: prompt
  });
};

/**
 * Universal website analysis and landing page generation system
 */
const extractProjectData = async (url) => {
  try {
    const response = await axios.get(url, {
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
      }
    });

    const $ = cheerio.load(response.data);
    
    // ============ STEP 1: CLEAN BRAND NAME EXTRACTION ============
    let projectName = '';
    
    // Priority 1: og:site_name
    projectName = $('meta[property="og:site_name"]').attr('content')?.trim() || '';
    
    // Priority 2: application-name
    if (!projectName) {
      projectName = $('meta[name="application-name"]').attr('content')?.trim() || '';
    }
    
    // Priority 3: Logo alt text (cleaned)
    if (!projectName) {
      const logoAlt = $('img[alt*="logo" i], img[class*="logo" i], img[src*="logo" i]').first().attr('alt') || '';
      projectName = logoAlt.replace(/logo/gi, '').trim();
    }
    
    // Priority 4: Title cleaning
    if (!projectName) {
      const title = $('title').text().trim();
      if (title) {
        const parts = title.split(/[|:\-]/).map(p => p.trim());
        const meaningfulParts = parts.filter(p => 
          p.length > 2 && 
          p.length < 30 && 
          !p.includes('Home') && 
          !p.includes('Page') &&
          !p.includes('Official')
        );
        projectName = meaningfulParts.length > 0 ? 
          meaningfulParts.reduce((shortest, current) => current.length < shortest.length ? current : shortest) : 
          parts[0];
      }
    }
    
    // Priority 5: Domain fallback
    if (!projectName) {
      try {
        const domain = new URL(url).hostname.replace('www.', '');
        projectName = domain
          .split('.')
          .slice(0, -1)
          .join('.')
          .replace(/([a-z])([A-Z])/g, '$1 $2')
          .replace(/-/g, ' ')
          .replace(/\b\w/g, l => l.toUpperCase());
      } catch (e) {
        projectName = 'Unknown Brand';
      }
    }
    
    // Clean project name - remove marketing words
    projectName = projectName
      .replace(/\b(get|start|learn|discover|boost|grow|improve|transform)\b/gi, '')
      .replace(/\s+/g, ' ')
      .trim();
    
    // ============ STEP 2: SEO DATA EXTRACTION ============
    const projectDesc = $('meta[name="description"]').attr('content')?.trim() || 
                       $('meta[property="og:description"]').attr('content')?.trim() || '';
    
    let projectLogo = $('meta[property="og:image"]').attr('content')?.trim() || '';
    if (!projectLogo) {
      const logoImg = $('img[alt*="logo" i], img[class*="logo" i], img[src*="logo" i]').first();
      projectLogo = logoImg.attr('src')?.trim() || '';
    }
    if (projectLogo && !projectLogo.startsWith('http')) {
      projectLogo = new URL(projectLogo, url).href;
    }
    
    // Color extraction - get both primary and secondary colors
    let primaryColor = '';
    let secondaryColor = '';
    
    // Extract dominant color from logo
    if (projectLogo) {
      try {
        const logoColor = await extractDominantColorFromLogo(projectLogo);
        if (logoColor) {
          primaryColor = logoColor;
        }
      } catch (e) {
        // If logo extraction fails, continue with other methods
        logger.warn(`Logo color extraction failed: ${e.message}`);
      }
    }
    
    // Primary color from theme-color meta (fallback if logo extraction didn't work)
    if (!primaryColor) {
      primaryColor = $('meta[name="theme-color"]').attr('content')?.trim() || '';
    }
    
    // Extract colors from CSS and inline styles
    const colorSet = new Set();
    
    // From inline styles
    $('[style*="color"]').each((i, el) => {
      const style = $(el).attr('style') || '';
      const colorMatch = style.match(/color:\s*([#]?[a-fA-F0-9]{3,6}|rgb\([^)]+\)|rgba\([^)]+\))/gi);
      if (colorMatch) {
        colorMatch.forEach(color => {
          const cleanColor = color.replace(/color:\s*/i, '').trim();
          if (cleanColor.startsWith('#') || cleanColor.startsWith('rgb')) {
            colorSet.add(cleanColor);
          }
        });
      }
    });
    
    // From CSS classes that commonly contain colors
    const colorClasses = ['primary', 'secondary', 'accent', 'main', 'brand', 'theme'];
    colorClasses.forEach(className => {
      $(`[class*="${className}"]`).each((i, el) => {
        const style = $(el).attr('style') || '';
        const colorMatch = style.match(/(?:color|background|background-color):\s*([#]?[a-fA-F0-9]{3,6}|rgb\([^)]+\)|rgba\([^)]+\))/gi);
        if (colorMatch) {
          colorMatch.forEach(color => {
            const cleanColor = color.replace(/(?:color|background|background-color):\s*/i, '').trim();
            if (cleanColor.startsWith('#') || cleanColor.startsWith('rgb')) {
              colorSet.add(cleanColor);
            }
          });
        }
      });
    });
    
    // Convert RGB to hex for consistency
    const rgbToHex = (rgb) => {
      if (rgb.startsWith('#')) return rgb;
      const match = rgb.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
      if (match) {
        const r = parseInt(match[1]).toString(16).padStart(2, '0');
        const g = parseInt(match[2]).toString(16).padStart(2, '0');
        const b = parseInt(match[3]).toString(16).padStart(2, '0');
        return `#${r}${g}${b}`;
      }
      return rgb;
    };
    
    const colors = Array.from(colorSet).map(rgbToHex).filter(c => c.startsWith('#'));
    
    // Set primary color if not found
    if (!primaryColor && colors.length > 0) {
      primaryColor = colors[0];
    }
    
    // Set secondary color (different from primary)
    secondaryColor = colors.find(c => c !== primaryColor) || '';
    
    // Additional fallback: extract from most common color in body
    if (!primaryColor && colors.length === 0) {
      $('body, header, nav, .header, .navbar').each((i, el) => {
        const style = $(el).attr('style') || '';
        const colorMatch = style.match(/(?:color|background|background-color):\s*([#]?[a-fA-F0-9]{3,6}|rgb\([^)]+\)|rgba\([^)]+\))/gi);
        if (colorMatch && !primaryColor) {
          const cleanColor = colorMatch[0].replace(/(?:color|background|background-color):\s*/i, '').trim();
          if (cleanColor.startsWith('#') || cleanColor.startsWith('rgb')) {
            primaryColor = cleanColor.startsWith('#') ? cleanColor : rgbToHex(cleanColor);
          }
        }
      });
    }
    
    // Final fallback: use first color from any element if still none found
    if (!primaryColor && colors.length > 0) {
      primaryColor = colors[0];
    }
    if (!secondaryColor && colors.length > 1) {
      secondaryColor = colors[1];
    }
    
    // Ultimate fallback: extract from link colors if still no colors
    if (!primaryColor && colors.length === 0) {
      $('a').each((i, el) => {
        const style = $(el).attr('style') || '';
        const colorMatch = style.match(/color:\s*([#]?[a-fA-F0-9]{3,6}|rgb\([^)]+\)|rgba\([^)]+\))/i);
        if (colorMatch && !primaryColor) {
          const cleanColor = colorMatch[0].replace(/color:\s*/i, '').trim();
          if (cleanColor.startsWith('#') || cleanColor.startsWith('rgb')) {
            primaryColor = cleanColor.startsWith('#') ? cleanColor : rgbToHex(cleanColor);
          }
        }
      });
    }
    
    // If still no colors, extract from any element with background
    if (!primaryColor) {
      $('[style*="background"], [style*="background-color"]').first().each((i, el) => {
        const style = $(el).attr('style') || '';
        const colorMatch = style.match(/background(?:-color)?:\s*([#]?[a-fA-F0-9]{3,6}|rgb\([^)]+\)|rgba\([^)]+\))/i);
        if (colorMatch) {
          const cleanColor = colorMatch[0].replace(/background(?:-color)?:\s*/i, '').trim();
          if (cleanColor.startsWith('#') || cleanColor.startsWith('rgb')) {
            primaryColor = cleanColor.startsWith('#') ? cleanColor : rgbToHex(cleanColor);
          }
        }
      });
    }
    
    // ============ STEP 3: SMART SERVICE EXTRACTION ============
    const services = new Set();
    
    // LAYER 1: URL-based extraction
    $('a[href*="service" i], a[href*="product" i], a[href*="solution" i], a[href*="seo" i], a[href*="marketing" i], a[href*="design" i], a[href*="development" i]').each((i, el) => {
      const text = $(el).text().trim();
      if (text && text.length > 2 && text.length < 60 && !isCTA(text)) {
        services.add(text);
      }
    });
    
    // LAYER 2: Section-based extraction
    $('section, div, article').each((i, el) => {
      const id = $(el).attr('id')?.toLowerCase() || '';
      const cls = $(el).attr('class')?.toLowerCase() || '';
      
      if (id.includes('service') || id.includes('feature') || id.includes('solution') ||
          cls.includes('service') || cls.includes('feature') || cls.includes('solution') ||
          cls.includes('offering') || cls.includes('product')) {
        
        $(el).find('h2, h3, h4, h5, h6').each((j, item) => {
          const text = $(item).text().trim();
          if (text && text.length > 2 && text.length < 60 && !isCTA(text) && !isSentence(text)) {
            services.add(text);
          }
        });
      }
    });
    
    // LAYER 3: Structured lists in service sections
    $('section, div, article').each((i, el) => {
      const id = $(el).attr('id')?.toLowerCase() || '';
      const cls = $(el).attr('class')?.toLowerCase() || '';
      
      if (id.includes('service') || id.includes('feature') || id.includes('solution') ||
          cls.includes('service') || cls.includes('feature') || cls.includes('solution')) {
        
        $(el).find('li').each((j, item) => {
          const text = $(item).text().trim();
          if (text && text.length > 2 && text.length < 60 && !isCTA(text) && !isSentence(text)) {
            services.add(text);
          }
        });
      }
    });
    
    // LAYER 4: Schema markup extraction
    $('script[type="application/ld+json"]').each((i, el) => {
      try {
        const schema = JSON.parse($(el).text());
        if (Array.isArray(schema)) {
          schema.forEach(item => extractServicesFromSchema(item, services));
        } else {
          extractServicesFromSchema(schema, services);
        }
      } catch (e) {
        // Skip invalid JSON
      }
    });
    
    // FALLBACK: Use keywords if no services found
    if (services.size < 3 && keywords.length > 0) {
      keywords.slice(0, 10).forEach(keyword => {
        if (keyword.length > 2 && keyword.length < 60 && !isCTA(keyword)) {
          services.add(keyword);
        }
      });
    }
    
    // FALLBACK: Generate services from project name
    if (services.size < 3) {
      const generatedServices = generateServicesFromProjectName(projectName);
      generatedServices.forEach(service => services.add(service));
    }
    
    // Clean and filter services
    const cleanedServices = [...services]
      .filter(service => 
        service.length > 2 && 
        service.length < 60 && 
        !isCTA(service) && 
        !isSentence(service) &&
        !service.includes('©') &&
        !service.includes('All rights reserved')
      )
      .slice(0, 15);
    
    // ============ STEP 4: ENHANCED KEYWORD EXTRACTION ============
    let keywords = $('meta[name="keywords"]').attr('content')?.split(',').map(k => k.trim()).filter(k => k) || [];
    
    // If no meta keywords, generate from services and content
    if (keywords.length === 0) {
      const generatedKeywords = new Set();
      
      // Add services as keywords
      cleanedServices.forEach(service => {
        if (service.length > 2 && service.length < 30) {
          generatedKeywords.add(service.toLowerCase());
        }
      });
      
      // Extract keywords from title and description
      const titleWords = projectName.toLowerCase().split(/\s+/).filter(w => w.length > 2);
      const descWords = projectDesc.toLowerCase().split(/\s+/).filter(w => w.length > 3);
      
      titleWords.forEach(word => generatedKeywords.add(word));
      descWords.slice(0, 10).forEach(word => generatedKeywords.add(word));
      
      // Common industry keywords based on content
      const content = $('body').text().toLowerCase();
      const industryKeywords = [
        'digital marketing', 'seo', 'web design', 'agency', 'marketing',
        'social media', 'ppc', 'advertising', 'branding', 'content',
        'development', 'consulting', 'strategy', 'optimization', 'analytics'
      ];
      
      industryKeywords.forEach(keyword => {
        if (content.includes(keyword)) {
          generatedKeywords.add(keyword);
        }
      });
      
      keywords = Array.from(generatedKeywords).slice(0, 15);
    }
    
    // Detect industry from services
    const detectedIndustry = detectIndustryFromServices(cleanedServices);
    
    // Get all extracted colors (for database storage)
    const allColors = colors.length > 0 ? colors.slice(0, 10) : [];
    if (primaryColor && !allColors.includes(primaryColor)) {
      allColors.push(primaryColor);
    }
    if (secondaryColor && !allColors.includes(secondaryColor)) {
      allColors.push(secondaryColor);
    }
    
    return {
      websiteUrl: url,
      projectName: projectName || 'Unknown Brand',
      projectDesc,
      projectLogo,
      theme: primaryColor, // Keep theme for backward compatibility
      primaryColor,
      secondaryColor,
      colors: allColors, // All extracted colors for database storage
      services: cleanedServices,
      keywords,
      industry: detectedIndustry
    };
  } catch (err) {
    logger.error(`Extraction failed for ${url}: ${err.message}`);
    throw new Error(`Failed to extract data: ${err.message}`);
  }
};

// Helper functions
const isCTA = (text) => {
  const ctaWords = ['get', 'start', 'learn', 'discover', 'boost', 'grow', 'improve', 'transform', 'contact', 'call', 'email'];
  const lowerText = text.toLowerCase();
  return ctaWords.some(word => lowerText.includes(word));
};

const isSentence = (text) => {
  return text.length > 60 || text.includes('.') || text.includes('?') || text.includes('!');
};

const extractServicesFromSchema = (schema, services) => {
  if (schema['@type'] === 'Service' || schema['@type'] === 'Product') {
    if (schema.name) services.add(schema.name);
    if (schema.serviceType) services.add(schema.serviceType);
    if (schema.category) services.add(schema.category);
  }
  
  if (schema.offers && Array.isArray(schema.offers)) {
    schema.offers.forEach(offer => {
      if (offer.itemOffered && offer.itemOffered.name) {
        services.add(offer.itemOffered.name);
      }
    });
  }
};

const extractDominantColorFromLogo = async (logoUrl) => {
  try {
    // Download the image as buffer
    const response = await axios.get(logoUrl, {
      responseType: 'arraybuffer',
      timeout: 5000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      }
    });
    
    const imageBuffer = Buffer.from(response.data);
    
    // Check if this is a valid image by looking at common signatures
    const isPNG = imageBuffer[0] === 0x89 && imageBuffer[1] === 0x50 && imageBuffer[2] === 0x4E && imageBuffer[3] === 0x47;
    const isJPEG = imageBuffer[0] === 0xFF && imageBuffer[1] === 0xD8 && imageBuffer[2] === 0xFF;
    const isGIF = imageBuffer[0] === 0x47 && imageBuffer[1] === 0x49 && imageBuffer[2] === 0x46;
    const isWEBP = imageBuffer[8] === 0x57 && imageBuffer[9] === 0x45 && imageBuffer[10] === 0x42 && imageBuffer[11] === 0x50;
    
    if (!isPNG && !isJPEG && !isGIF && !isWEBP) {
      logger.warn('Unsupported image format for color extraction');
      return null;
    }
    
    // Simple color extraction using a sampling approach
    // For PNG, we can try to find pixel data after headers
    let pixelData = null;
    
    if (isPNG) {
      // Very basic PNG parsing - look for IDAT chunks
      // This is simplified and may not work for all PNGs
      for (let i = 8; i < Math.min(imageBuffer.length, 1000); i++) {
        if (imageBuffer[i] === 0x49 && imageBuffer[i + 1] === 0x44 && imageBuffer[i + 2] === 0x41 && imageBuffer[i + 3] === 0x54) {
          // Found IDAT chunk, start sampling after chunk header
          const dataStart = i + 8;
          pixelData = imageBuffer.slice(dataStart, Math.min(dataStart + 5000, imageBuffer.length));
          break;
        }
      }
    } else if (isJPEG) {
      // For JPEG, sample from the middle of the file (after headers)
      const start = Math.floor(imageBuffer.length / 2);
      pixelData = imageBuffer.slice(start, Math.min(start + 5000, imageBuffer.length));
    } else {
      // For other formats, sample from the middle
      const start = Math.floor(imageBuffer.length / 2);
      pixelData = imageBuffer.slice(start, Math.min(start + 5000, imageBuffer.length));
    }
    
    if (!pixelData || pixelData.length < 12) {
      return null;
    }
    
    // Sample colors from the buffer
    const colorCounts = {};
    for (let i = 0; i < pixelData.length - 2; i += 3) {
      const r = pixelData[i] & 0xFF;
      const g = pixelData[i + 1] & 0xFF;
      const b = pixelData[i + 2] & 0xFF;
      
      // Skip very dark or very light colors (likely backgrounds)
      const brightness = (r + g + b) / 3;
      if (brightness > 20 && brightness < 235) {
        // Quantize to reduce color variations
        const qr = Math.round(r / 16) * 16;
        const qg = Math.round(g / 16) * 16;
        const qb = Math.round(b / 16) * 16;
        const colorKey = `${qr},${qg},${qb}`;
        colorCounts[colorKey] = (colorCounts[colorKey] || 0) + 1;
      }
    }
    
    // Find the most common color
    let maxCount = 0;
    let dominantColor = null;
    for (const [colorKey, count] of Object.entries(colorCounts)) {
      if (count > maxCount) {
        maxCount = count;
        dominantColor = colorKey;
      }
    }
    
    if (dominantColor) {
      const [r, g, b] = dominantColor.split(',').map(Number);
      return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
    }
    
    return null;
  } catch (error) {
    logger.warn(`Failed to extract color from logo: ${error.message}`);
    return null;
  }
};

const detectIndustryFromServices = (services) => {
  if (!services || services.length === 0) return 'General';
  
  const serviceText = services.join(' ').toLowerCase();
  
  // Industry detection based on service keywords
  const industryMap = {
    'seo': 'SEO & Digital Marketing',
    'marketing': 'Digital Marketing',
    'web design': 'Web Design',
    'design': 'Design',
    'development': 'Software Development',
    'app development': 'Software Development',
    'software': 'Software Development',
    'consulting': 'Consulting',
    'consultancy': 'Consulting',
    'agency': 'Digital Agency',
    'advertising': 'Advertising',
    'ppc': 'Digital Marketing',
    'social media': 'Digital Marketing',
    'branding': 'Branding',
    'logo': 'Design',
    'hosting': 'Technology',
    'cloud': 'Technology',
    'security': 'Technology',
    'analytics': 'Analytics',
    'data': 'Technology',
    'fitness': 'Health & Fitness',
    'gym': 'Health & Fitness',
    'training': 'Education',
    'course': 'Education',
    'learning': 'Education',
    'real estate': 'Real Estate',
    'property': 'Real Estate',
    'insurance': 'Insurance',
    'finance': 'Finance',
    'banking': 'Finance',
    'legal': 'Legal',
    'healthcare': 'Healthcare',
    'medical': 'Healthcare',
    'restaurant': 'Food & Restaurant',
    'ecommerce': 'E-commerce',
    'shop': 'E-commerce',
    'store': 'E-commerce'
  };
  
  // Check each industry keyword against services
  for (const [keyword, industry] of Object.entries(industryMap)) {
    if (serviceText.includes(keyword)) {
      return industry;
    }
  }
  
  return 'General';
};

const generateServicesFromProjectName = (projectName) => {
  const name = projectName.toLowerCase();
  
  if (name.includes('fitness') || name.includes('gym')) {
    return ['Personal Training', 'Gym Membership', 'Yoga Classes', 'Nutrition Coaching'];
  }
  if (name.includes('agency') || name.includes('marketing')) {
    return ['Digital Marketing', 'SEO Services', 'Web Design', 'Content Creation'];
  }
  if (name.includes('design') || name.includes('creative')) {
    return ['Brand Design', 'UI/UX Design', 'Logo Design', 'Graphic Design'];
  }
  if (name.includes('tech') || name.includes('software')) {
    return ['Software Development', 'Web Development', 'Mobile Apps', 'Cloud Solutions'];
  }
  if (name.includes('consulting') || name.includes('advisor')) {
    return ['Business Consulting', 'Strategy Planning', 'Market Research', 'Growth Advisory'];
  }
  
  return ['Professional Services', 'Expert Consulting', 'Custom Solutions', 'Quality Support'];
};

module.exports = { analyzeWebsite, inspectWebsite, extractProjectData };
