const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Project must belong to a user'],
  },
  name: {
    type: String,
    required: [true, 'Please provide a project name'],
    trim: true,
  },
  description: {
    type: String,
    trim: true,
  },
  isDeleted: {
    type: Boolean,
    default: false,
    select: false,
  },
  apiToken: {
    type: String,
    unique: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
  pageCount: {
    type: Number,
    default: 0,
  },
  leadCount: {
    type: Number,
    default: 0,
  },
  websiteUrl: {
    type: String,
    required: [true, 'Please provide a website URL'],
    trim: true,
    lowercase: true,
  },
  logoUrl: {
    type: String,
  },
  industry: {
    type: String,
  },
  primaryColor: {
    type: String,
    default: '#7c3aed',
  },
  secondaryColor: {
    type: String,
    default: '#6366f1',
  },
});

// Middleware to normalize websiteUrl
projectSchema.pre('validate', function(next) {
  if (this.websiteUrl) {
    // Remove trailing slash and convert to lowercase (already handled by schema option)
    this.websiteUrl = this.websiteUrl.replace(/\/+$/, '');
  }
  next();
});

// Middleware to update updatedAt and generate apiToken
projectSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  
  if (!this.apiToken) {
    const crypto = require('crypto');
    this.apiToken = 'PC-' + crypto.randomBytes(8).toString('hex').toUpperCase();
  }
  
  next();
});

// Soft delete query middleware
projectSchema.pre(/^find/, function (next) {
  this.find({ isDeleted: { $ne: true } });
  next();
});

const Project = mongoose.model('Project', projectSchema);
module.exports = Project;
